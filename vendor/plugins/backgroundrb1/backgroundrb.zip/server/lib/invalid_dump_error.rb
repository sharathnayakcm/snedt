module BackgrounDRb
  class InvalidDumpError < RuntimeError
  end
end
